﻿namespace Supercell.Laser.Logic
{
    public class GameVersion
    {
        public const int MAJOR = 27;
        public const int BUILD = 269;
    }
}