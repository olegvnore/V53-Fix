﻿using System;

namespace Atrasis.Magic.Servers.Core.Libs.ZLib
{
	// Token: 0x020000DF RID: 223
	internal enum ZlibStreamFlavor
	{
		// Token: 0x0400037E RID: 894
		ZLIB = 1950,
		// Token: 0x0400037F RID: 895
		DEFLATE,
		// Token: 0x04000380 RID: 896
		GZIP
	}
}
