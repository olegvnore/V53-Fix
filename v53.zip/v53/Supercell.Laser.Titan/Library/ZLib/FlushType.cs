﻿using System;

namespace Atrasis.Magic.Servers.Core.Libs.ZLib
{
	// Token: 0x020000D6 RID: 214
	public enum FlushType
	{
		// Token: 0x0400034C RID: 844
		None,
		// Token: 0x0400034D RID: 845
		Partial,
		// Token: 0x0400034E RID: 846
		Sync,
		// Token: 0x0400034F RID: 847
		Full,
		// Token: 0x04000350 RID: 848
		Finish
	}
}
