﻿using System;

namespace Atrasis.Magic.Servers.Core.Libs.ZLib
{
	// Token: 0x020000D8 RID: 216
	public enum CompressionStrategy
	{
		// Token: 0x04000361 RID: 865
		Default,
		// Token: 0x04000362 RID: 866
		Filtered,
		// Token: 0x04000363 RID: 867
		HuffmanOnly
	}
}
