﻿using System;

namespace Atrasis.Magic.Servers.Core.Libs.ZLib
{
	// Token: 0x020000C5 RID: 197
	internal enum DeflateFlavor
	{
		// Token: 0x04000239 RID: 569
		Store,
		// Token: 0x0400023A RID: 570
		Fast,
		// Token: 0x0400023B RID: 571
		Slow
	}
}
