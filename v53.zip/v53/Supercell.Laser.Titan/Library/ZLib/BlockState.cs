﻿using System;

namespace Atrasis.Magic.Servers.Core.Libs.ZLib
{
	// Token: 0x020000C4 RID: 196
	internal enum BlockState
	{
		// Token: 0x04000234 RID: 564
		NeedMore,
		// Token: 0x04000235 RID: 565
		BlockDone,
		// Token: 0x04000236 RID: 566
		FinishStarted,
		// Token: 0x04000237 RID: 567
		FinishDone
	}
}
