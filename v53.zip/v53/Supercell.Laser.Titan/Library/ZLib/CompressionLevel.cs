﻿using System;

namespace Atrasis.Magic.Servers.Core.Libs.ZLib
{
	// Token: 0x020000D7 RID: 215
	public enum CompressionLevel
	{
		// Token: 0x04000352 RID: 850
		None,
		// Token: 0x04000353 RID: 851
		Level0 = 0,
		// Token: 0x04000354 RID: 852
		BestSpeed,
		// Token: 0x04000355 RID: 853
		Level1 = 1,
		// Token: 0x04000356 RID: 854
		Level2,
		// Token: 0x04000357 RID: 855
		Level3,
		// Token: 0x04000358 RID: 856
		Level4,
		// Token: 0x04000359 RID: 857
		Level5,
		// Token: 0x0400035A RID: 858
		Default,
		// Token: 0x0400035B RID: 859
		Level6 = 6,
		// Token: 0x0400035C RID: 860
		Level7,
		// Token: 0x0400035D RID: 861
		Level8,
		// Token: 0x0400035E RID: 862
		BestCompression,
		// Token: 0x0400035F RID: 863
		Level9 = 9
	}
}
