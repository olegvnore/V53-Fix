﻿using System;

namespace Atrasis.Magic.Servers.Core.Libs.ZLib
{
	// Token: 0x020000D9 RID: 217
	public enum CompressionMode
	{
		// Token: 0x04000365 RID: 869
		Compress,
		// Token: 0x04000366 RID: 870
		Decompress
	}
}
